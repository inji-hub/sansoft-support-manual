"""학습용 도식과 출처가 있는 매뉴얼 화면. 원본 PDF는 수정하지 않는다."""
from pathlib import Path
import streamlit as st
ROOT = Path(__file__).resolve().parent


def diagram(name, caption):
    st.image(str(ROOT / "assets/diagrams" / (name + ".svg")), width="stretch")
    st.caption(caption)


def manual_pages(pages):
    with st.expander("매뉴얼 화면으로 확인하기"):
        st.caption("출처: QC MANUAL.pdf · PDF 파일 기준 페이지. 매뉴얼 예시이며 실제 문의 화면이 아닙니다. 사용 버전에 따라 화면이 다를 수 있습니다.")
        for page in pages:
            st.image(str(ROOT / "assets/manuals" / f"qc-manual-{page:02d}.png"), caption=f"QC MANUAL.pdf · {page}쪽", width="stretch")


def article_visual(article_id):
    if article_id == "flow":
        diagram("data-flow", "번호는 확인 관점을 정리한 학습용 순서입니다. 실제 구조를 고정한 시스템 구성도가 아닙니다.")
    elif article_id == "mapping":
        diagram("channel-matching", "Sample ID는 Control 정보에, 검사 결과코드는 검사항목에 연결합니다.")


def wbc_summary(case):
    st.write(case["symptom"])
    diagram("wbc-case", "확인된 표시와 안내 내용을 재구성한 그림입니다. 해결 완료를 뜻하지 않습니다.")
    with st.container(border=True):
        st.markdown("**핵심: 전송완료와 웹 정상 반영은 별도 확인입니다.**")
        st.write("이 건에서는 웹 로그 상세 사유에서 WBC Lab Target Range 미등록을 확인했습니다.")
        st.write("등록 필요를 안내했으며, 이후 정상 반영 여부는 확인되지 않았습니다.")
    with st.expander("상세 기록 · 확인한 사실과 조치"):
        from cases import FIELDS
        for key, label in FIELDS.items():
            if key != "title" and case.get(key):
                st.markdown("**" + label + "**")
                st.write(case[key])
    with st.expander("후속 확인할 내용", expanded=True):
        st.markdown("- 해당 Control·Lot·Level과 항목의 범위 등록·적용 여부\n- Interface log 상태와 실제 웹 결과 조회\n- 기존 부분완료 결과의 추가 처리 필요 여부")
    manual_pages([8])
