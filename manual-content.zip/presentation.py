"""Shared document sections; original Markdown remains the editable content."""
from pathlib import Path
import re
import streamlit as st


def render_document(body, key, section_images=()):
    sections = re.split(r"(?m)(?=^## )", body)
    for index, section in enumerate(sections):
        if section.strip():
            with st.container(key=f"doc_section_{key}_{index}"):
                st.markdown(section)
                heading = section.split("\n", 1)[0].removeprefix("## ").strip()
                for item in section_images:
                    if item["heading"] == heading:
                        root = Path(__file__).resolve().parent
                        image_path = (root / item["path"]).resolve()
                        if image_path.is_relative_to(root) and image_path.is_file():
                            if item.get("side_by_side"):
                                picture, explanation = st.columns([1, 2], gap="large")
                                with picture:
                                    st.image(str(image_path), caption=item.get("caption", ""), width=item.get("width", "content"))
                                with explanation:
                                    st.markdown(item.get("explanation", ""))
                            else:
                                st.image(str(image_path), caption=item.get("caption", ""), width=item.get("width", "content"))
                                if item.get("explanation"):
                                    st.markdown(item["explanation"])
                            if item.get("source_url"):
                                st.caption(f'{item["credit"]} · [이미지 출처]({item["source_url"]}) · [{item["license"]}]({item["license_url"]})')
                        else:
                            st.warning("첨부 이미지를 찾을 수 없습니다.")
