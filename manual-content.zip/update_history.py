"""문서 최초 등록일을 수정일과 분리해 보관한다."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import json
import streamlit as st

ROOT = Path(__file__).resolve().parent


def creation_records(items, seed=None):
    if seed is None:
        seed = json.loads((ROOT / "content/creation_history.json").read_text(encoding="utf-8"))
    return [dict(item, created=seed[item["key"]][:10]) for item in items]


def history_page(records, open_entry):
    st.title("업데이트 내역")
    st.write("문서가 처음 추가된 날짜를 확인하고 바로 열어보세요.")
    st.caption("문구 수정·이미지 교체 등 세부 수정은 제외하고 생성 내역만 표시합니다.")
    kind_names = {"article": "문서", "term": "용어", "case": "문의 사례", "info": "기타 정보"}
    if st.session_state.get("history_kind") == "장비 안내":
        st.session_state["history_kind"] = "전체"
    dates = sorted({item["created"] for item in records}, reverse=True)
    left, right = st.columns(2)
    with left:
        selected_date = st.selectbox("생성일", ["전체"] + dates, key="history_date")
    with right:
        selected_kind = st.selectbox("자료 종류", ["전체"] + list(kind_names.values()), key="history_kind")
    query = st.text_input("제목 검색", placeholder="찾고 싶은 문서 제목을 입력하세요", key="history_query").strip().casefold()
    matches = [item for item in records
               if (selected_date == "전체" or item["created"] == selected_date)
               and (selected_kind == "전체" or kind_names[item["kind"]] == selected_kind)
               and query in item["title"].casefold()]
    st.caption(f"생성 기록 {len(matches)}개")
    if not matches:
        st.info("조건에 맞는 생성 기록이 없습니다.")
        return
    for index, day in enumerate(sorted({item["created"] for item in matches}, reverse=True)):
        daily = sorted((item for item in matches if item["created"] == day), key=lambda item:(item["category"], item["title"]))
        with st.expander(f"{day} · {len(daily)}개 추가", expanded=index == 0 or selected_date != "전체"):
            for item in daily:
                label, link = st.columns([5, 1], vertical_alignment="center")
                with label:
                    st.caption(item["category"])
                    st.write(item["title"])
                with link:
                    if st.button("열기", key="history_open_" + item["key"], width="stretch"):
                        open_entry(item)
