export default function(component) {
 const {data, parentElement, setTriggerValue}=component;
 const root=document.createElement('div');
 root.innerHTML=`<div class="search-row"><div class="input-wrap"><span aria-hidden="true">⌕</span><input type="search" placeholder="궁금한 용어나 주제를 입력하세요" aria-label="자료 검색" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="suggestions" autocomplete="off"></div><button class="submit">검색</button></div><div id="suggestions" role="listbox" hidden></div><span class="sr" role="status" aria-live="polite"></span>`;
 parentElement.appendChild(root);
 const input=root.querySelector('input'),list=root.querySelector('[role=listbox]'),status=root.querySelector('[role=status]');
 let matches=[],active=-1;
 const norm=s=>s.toLocaleLowerCase().replace(/\s+/g,'');
 function close(){list.hidden=true;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');active=-1;}
 function choose(item){close();setTriggerValue('selected',item.key);}
 function render(){
  const q=norm(input.value);active=-1;list.replaceChildren();input.removeAttribute('aria-activedescendant');
  if(!q){close();status.textContent='';return;}
  matches=data.filter(x=>norm(x.search).includes(q)).sort((a,b)=>Number(norm(b.title).includes(q))-Number(norm(a.title).includes(q))).slice(0,6);
  list.hidden=false;input.setAttribute('aria-expanded','true');
  status.textContent=matches.length+'개 추천 문서';
  if(!matches.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='일치하는 문서가 없습니다. 다른 검색어를 입력해 보세요.';list.appendChild(empty);return;}
  matches.forEach((item,i)=>{const row=document.createElement('div');row.id='suggestion-'+i;row.role='option';row.setAttribute('aria-selected','false');row.className='option';
   const title=document.createElement('span');title.textContent=item.title;
   const category=document.createElement('small');category.textContent=item.category;row.append(title,category);
   row.onmousedown=e=>e.preventDefault();row.onclick=()=>choose(item);list.appendChild(row);
  });
 }
 function submit(){if(input.value.trim())setTriggerValue('query',input.value.trim());}
 input.oninput=render;input.onfocus=()=>{if(input.value)render();};
 input.onkeydown=e=>{
  if(e.isComposing||e.keyCode===229)return;
  if(e.key==='Escape'){close();return;}
  if((e.key==='ArrowDown'||e.key==='ArrowUp')&&matches.length){e.preventDefault();if(list.hidden)render();active=(active+(e.key==='ArrowDown'?1:-1)+matches.length)%matches.length;[...list.children].forEach((el,i)=>el.setAttribute('aria-selected',String(i===active)));input.setAttribute('aria-activedescendant','suggestion-'+active);}
  if(e.key==='Enter'){e.preventDefault();if(!list.hidden&&active>=0)choose(matches[active]);else submit();}
 };
 input.onblur=()=>close();root.querySelector('.submit').onclick=submit;
 return ()=>root.remove();
}
