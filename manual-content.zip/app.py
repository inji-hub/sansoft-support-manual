"""업무 길잡이: 정리 글을 읽고 출처를 확인하는 로컬 웹 앱."""
from pathlib import Path
from contextlib import nullcontext
import json
import base64
import streamlit as st
import importlib
import cases as case_views

# Refresh the case renderer when its source changes during a running session.
_case_source_stamp = Path(case_views.__file__).stat().st_mtime_ns
if getattr(case_views, "_loaded_source_stamp", None) != _case_source_stamp:
    importlib.reload(case_views)
    case_views._loaded_source_stamp = _case_source_stamp
from cases import cases_page, open_case, get_cases
from glossary import filter_terms
import home as home_data

# Apply menu-routing changes even when Streamlit retains an imported module.
_home_source_stamp = Path(home_data.__file__).stat().st_mtime_ns
if getattr(home_data, "_loaded_source_stamp", None) != _home_source_stamp:
    importlib.reload(home_data)
    home_data._loaded_source_stamp = _home_source_stamp
from home import entries, favorites, set_favorite, article_page, articles_for_page, filter_articles
from update_history import creation_records, history_page
from presentation import render_document
from visuals import article_visual, manual_pages

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="업무 길잡이 | 산소프트 고객지원팀", page_icon="📖", layout="wide")
st.markdown("""
<style>
.stApp {background:#fbfcfe;color:#14253f}
[data-testid="stSidebar"] {background:#f5f8fa;border-right:1px solid #e3e9ed}
[data-testid="stSidebarUserContent"] {padding:1.6rem 1.25rem}
.sidebar-identity {color:#526675;font-size:.85rem;margin:0 0 2rem;letter-spacing:.02em}
[data-testid="stSidebar"] .nav-group {
    display:flex;align-items:center;gap:.75rem;
    color:#73838f;font-size:11px;font-weight:500;letter-spacing:.08em;
    margin:1.2rem 0 .75rem;line-height:1.5;cursor:default;
}
[data-testid="stSidebar"] .nav-group::after {
    content:"";flex:1;height:1px;background:#dce4e9;
}
[data-testid="stSidebar"] .stButton button {
    justify-content:flex-start;min-height:52px;padding:.75rem .85rem;
    border:1px solid transparent;border-radius:7px;box-shadow:none;
}
[data-testid="stSidebar"] .stButton button p {
    font-size:18px;line-height:1.5;letter-spacing:.02em;white-space:normal;
}
[data-testid="stSidebar"] .stButton button[kind="secondary"] {background:transparent;color:#435666}
[data-testid="stSidebar"] .stButton button[kind="secondary"]:hover {background:#e9eff3;color:#193541}
[data-testid="stSidebar"] .stButton button[kind="primary"] {background:#deeeee;color:#24666c;border-color:#d2e5e5}
[data-testid="stSidebar"] .stButton button[kind="primary"] p {font-weight:650}
[data-testid="stSidebar"] .stButton button > div {justify-content:flex-start;width:100%}
[data-testid="stSidebar"] .stButton button:focus-visible {outline:2px solid #378b90;outline-offset:2px}
h1,h2,h3 {color:#14253f;letter-spacing:0}
[data-testid="stMainBlockContainer"] {padding-top:5rem;max-width:1400px}
.stButton button {border-radius:10px}
.st-key-reading_outline {background:#f2f6f8;border-color:#e0e7ec;border-radius:12px;padding:1.1rem}
.st-key-reading_outline h3 {font-size:1.1rem}
.st-key-reading_outline .stButton button {min-height:48px;text-align:left;border:0;background:transparent;color:#435666}
.st-key-reading_outline .stButton button > div {justify-content:flex-start;width:100%}
.st-key-reading_outline .stButton button[kind="primary"] {background:#deeeee;color:#24666c;box-shadow:inset 3px 0 #378b90}
.st-key-reading_outline .stButton button[kind="primary"] p {font-weight:650}
.st-key-reading_outline .stButton button:hover {background:#e5eef1}
.st-key-reading_header, .st-key-reading_body, .st-key-reading_sources {
    background:#fff;border-color:#e0e7ec;border-radius:12px;padding:1.5rem;
}
.st-key-reading_header {border-top:3px solid #378b90}
.st-key-reading_header h2 {font-size:1.8rem}
.st-key-reading_body h2 {font-size:1.25rem;margin-top:1.5rem;padding-bottom:.65rem;border-bottom:1px solid #e8edf1}
.st-key-reading_body h2:first-child {margin-top:0}

.st-key-reading_sources {background:#f5f8fa}
.st-key-reading_sources h3 {font-size:1.05rem}

/* Shared reading rhythm: articles, case details, manuals and glossary. */
[data-testid="stMain"] [data-testid="stMarkdown"] p,
[data-testid="stMain"] [data-testid="stMarkdown"] li {
    font-size:16px;letter-spacing:.02em;line-height:1.8;overflow-wrap:anywhere;
}
[data-testid="stMain"] [data-testid="stMarkdown"] p {margin-bottom:1em}
[data-testid="stMain"] [data-testid="stMarkdown"] li {margin-bottom:.55rem}
[data-testid="stMain"] [data-testid="stMarkdown"] ul,
[data-testid="stMain"] [data-testid="stMarkdown"] ol {margin-bottom:1.4rem}
[data-testid="stMain"] [data-testid="stMarkdown"] :is(h1,h2,h3,h4) {
    line-height:1.5;letter-spacing:.01em;padding-bottom:.65rem;margin-bottom:1rem;
    overflow-wrap:anywhere;
}
[data-testid="stMain"] [data-testid="stMarkdown"] :is(p,ul,ol,blockquote,table) + :is(h2,h3,h4) {
    margin-top:2rem;
}
.st-key-reading_body [data-testid="stMarkdown"] h2 {margin-top:2rem;margin-bottom:1.15rem}
.st-key-reading_body [data-testid="stMarkdown"] h2:first-child {margin-top:0}
/* Tables stay more compact than prose and scroll inside their own container. */
[data-testid="stMarkdownContainer"] table {display:block;max-width:100%;overflow-x:auto}
[data-testid="stMarkdownContainer"] :is(th,td) {
    padding:.7rem .9rem;line-height:1.8;letter-spacing:.02em;vertical-align:top;
    font-size:16px;min-width:8rem;white-space:normal;overflow-wrap:anywhere;
}
/* Inputs have their own rhythm; do not stretch select boxes or icon glyphs. */
[data-testid="stTextInput"] input,
[data-testid="stNumberInput"] input {letter-spacing:.025em;line-height:1.5}
[data-testid="stTextArea"] textarea {font-size:16px;letter-spacing:.02em;line-height:1.8;padding:.75rem;min-height:110px}
[data-testid="stWidgetLabel"] p {letter-spacing:.015em;line-height:1.5;margin-bottom:0}
/* Control labels must not inherit the spacing intended for long-form reading. */
:is(.stButton,.stDownloadButton,.stFormSubmitButton) button {
    height:auto;min-height:2.65rem;padding:.6rem .9rem;
}
:is(.stButton,.stDownloadButton,.stFormSubmitButton) button p,
[data-baseweb="tab"] p,
[data-testid="stExpander"] summary p,
[data-testid="stRadio"] label p,
[data-testid="stCheckbox"] label p {
    letter-spacing:.01em;line-height:1.5;margin:0;white-space:normal;overflow-wrap:anywhere;
}
[data-baseweb="select"], [role="listbox"] {letter-spacing:.01em;line-height:1.5}


/* Search controls are visually distinct from category/status filters. */
[data-testid="stSelectbox"]:has(input[aria-label$="검색"]) [role="group"],
.st-key-home_search_input [data-testid="stTextInputRootElement"] {
    min-height:58px;border:1.5px solid #80b5b8;border-radius:12px;
    background:#fff;box-shadow:0 3px 12px rgba(36,102,108,.07);
}
[data-testid="stSelectbox"]:has(input[aria-label$="검색"]) [role="group"] {
    position:relative;padding-left:2.6rem;
}
[data-testid="stSelectbox"]:has(input[aria-label$="검색"]) [role="group"]::before {
    content:"";position:absolute;left:1rem;top:50%;transform:translateY(-50%);
    width:20px;height:20px;pointer-events:none;
    background:center / contain no-repeat url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23378b90' stroke-width='2' stroke-linecap='round'%3E%3Ccircle cx='10.5' cy='10.5' r='6.5'/%3E%3Cpath d='m16 16 5 5'/%3E%3C/svg%3E");
}
[data-testid="stSelectbox"]:has(input[aria-label$="검색"]) input,
.st-key-home_search_input input {font-size:1.05rem;min-width:0;line-height:1.5}
[data-testid="stSelectbox"]:has(input[aria-label$="검색"]) [role="group"]:focus-within,
.st-key-home_search_input [data-testid="stTextInputRootElement"]:focus-within {
    border-color:#378b90;box-shadow:0 0 0 3px rgba(55,139,144,.15);
}
[data-testid="stSelectbox"]:has(input[aria-label$="검색"]) [data-testid="stWidgetLabel"] p {
    font-weight:650;color:#24666c;margin-bottom:.25rem;
}
/* Match both controls within the home form, including its submit button. */
[data-testid="stForm"]:has(.st-key-home_search_input) [data-testid="stTextInputRootElement"],
[data-testid="stForm"]:has(.st-key-home_search_input) [data-testid="stFormSubmitButton"] button {
    height:58px;min-height:58px;box-sizing:border-box;
}
[data-testid="stForm"]:has(.st-key-home_search_input) [data-testid="stFormSubmitButton"] button {
    padding-top:0;padding-bottom:0;display:flex;align-items:center;justify-content:center;
}


/* Compact home lists, with a quiet onboarding strip. */
.st-key-home_recent [class*="_row_"], .st-key-home_favorites [class*="_row_"] {
    border-bottom:1px solid #e2e9ed;padding:.65rem 0;
}
.st-key-home_recent button, .st-key-home_favorites button {
    background:transparent;border:0;text-align:left;justify-content:flex-start;
    padding:.25rem 0;box-shadow:none;
}
.st-key-home_recent button:hover, .st-key-home_favorites button:hover {color:#247c81;background:#edf6f6}
.st-key-home_recent p, .st-key-home_favorites p {margin-bottom:.25rem}
.st-key-home_welcome {background:#edf5f6;border-radius:12px;padding:1.1rem 1.4rem}


/* Same Material star geometry in both bookmark states. */
[class*="st-key-favorite_on_"] button [data-testid="stIconMaterial"] {
    color:#d99b00;font-variation-settings:'FILL' 1,'wght' 400,'GRAD' 0,'opsz' 24;
}
[class*="st-key-favorite_off_"] button [data-testid="stIconMaterial"] {
    color:#526675;font-variation-settings:'FILL' 0,'wght' 400,'GRAD' 0,'opsz' 24;
}
[class*="st-key-favorite_on_"] button [data-testid="stIconMaterial"],
[class*="st-key-favorite_off_"] button [data-testid="stIconMaterial"] {
    font-size:20px;line-height:1;
}


[class*="st-key-favorite_on_detail_"] button,
[class*="st-key-favorite_off_detail_"] button {
    width:140px;min-height:44px;justify-content:center;
}


.sidebar-home-logo {display:inline-block;max-width:100%;border-radius:6px;cursor:pointer}
.sidebar-home-logo img {display:block;width:210px;max-width:100%;height:auto}
.sidebar-home-logo:focus-visible {outline:2px solid #378b90;outline-offset:5px}

</style>
""", unsafe_allow_html=True)


st.markdown("<style>" + (ROOT / "assets/reading-cards.css").read_text(encoding="utf-8") + "</style>", unsafe_allow_html=True)


def load_content():
    """글 목록과 본문을 매 실행 시 읽어 파일 수정 내용을 반영한다."""
    data = json.loads((ROOT / "content/catalog.json").read_text(encoding="utf-8"))
    for article in data["articles"]:
        article["body"] = (ROOT / "content" / article["file"]).read_text(encoding="utf-8")
        article["search_supplements"] = " ".join(item["body"] for item in article.get("supplements", []))
    return data


def navigate(page, article=None, query=None, view=None):
    if article:
        target = next((a for a in articles if a["id"] == article), None)
        if target:
            page = article_page(target)
    changes = {"page": page}
    prefix = {"업무 지식": "knowledge", "기초 지식": "basics", "검색 결과": "search"}.get(page)
    if article:
        changes["article"] = article
        if page == "기타 정보" and target:
            changes["other_info_choice"] = target["title"]
        if prefix:
            changes[prefix + "_article_choice"] = article
            changes[prefix + "_category"] = "전체"
            changes[prefix + "_classification"] = "전체"
    if view:
        changes["knowledge_view"] = view
    if query is not None:
        changes["query"] = query
        if not article and prefix:
            changes[prefix + "_article_choice"] = None
            changes[prefix + "_category"] = "전체"
            changes[prefix + "_classification"] = "전체"
    st.session_state["_navigation"] = changes
    st.rerun()


def favorite_button(key, widget_key, compact=False):
    saved = key in favorites()
    state = "on" if saved else "off"
    with st.container(key="favorite_" + state + "_" + ("compact_" if compact else "detail_") + widget_key):
        label = "" if compact else "즐겨찾기"
        if st.button(label, icon=":material/star:", key=widget_key,
                     help="누르면 즐겨찾기에서 해제합니다." if saved else "누르면 즐겨찾기에 추가합니다."):
            set_favorite(key, not saved)
            st.rerun()


def open_home_entry(item):
    if item["kind"] == "article":
        navigate("업무 지식", item["id"], "")
    elif item["kind"] == "case":
        open_case(item["id"])
    elif item["kind"] == "device":
        navigate("홈")
    else:
        changes = {"page": "용어정리", "term_choice": item["id"], "term_category": "전체"} if item["kind"] == "term" else {"page": "기타 정보", "other_info_choice": item["id"]}
        st.session_state["_navigation"] = changes
        st.rerun()


def home_row(item, prefix):
    with st.container(key=prefix + "_row_" + item["key"]):
        label, star = st.columns([8, 1], vertical_alignment="center")
        with label:
            st.caption(item["category"] + " · " + item["updated"][:10])
            if st.button(item["title"], key=prefix + "_open_" + item["key"], width="stretch"):
                open_home_entry(item)
        with star:
            favorite_button(item["key"], prefix + "_star_" + item["key"], compact=True)


def show_article(article, sources, framed=False):
    with st.container(border=True, key="reading_header") if framed else nullcontext():
        st.caption(f'{article["category"]} · 초안 · {article["updated"]} 수정')
        if article.get("classification"):
            st.caption("업무구분 · " + article["classification"])
        st.header(article["title"])
        favorite_button("article:" + article["id"], "article_favorite_" + article["id"])
        if article["category"] != "임상병리학 기초":
            st.write(article["summary"])
    if not framed:
        st.divider()
    with st.container(border=True, key="reading_body") if framed else nullcontext():
        article_visual(article["id"])
        if article["category"] == "임상병리학 기초" and "|---" in article["body"].replace(" ", ""):
            st.caption("표가 화면보다 넓으면 표 안에서 좌우로 스크롤해 확인하세요.")
        if article["id"] == "remote-support":
            overview, *sections = article["body"].split("\n## ")
            render_document(overview, "remote_overview")
            tabs = st.tabs([section.split("\n", 1)[0] for section in sections])
            for section_index, (tab, section) in enumerate(zip(tabs, sections)):
                with tab:
                    render_document(section.split("\n", 1)[1], f"remote_{section_index}")
        else:
            render_document(article["body"], article["id"], article.get("section_images", []))
        for supplement in article.get("supplements", []):
            with st.expander(supplement["title"]):
                st.markdown(supplement["body"])
        if article["id"] == "mapping":
            manual_pages([11, 12])
    if st.button("업무 용어 모음 보기 →", key=f'glossary_{article["id"]}'):
        navigate("용어정리")
    for case_id in article.get("cases", []):
        case = next((c for c in get_cases() if c["id"] == case_id), None)
        if case and st.button("관련 사례 · " + case["title"], key=f'article_case_{case_id}'):
            open_case(case_id)
    if article.get("related"):
        st.subheader("함께 읽을 글")
        for related_id in article["related"]:
            related = next((a for a in articles if a["id"] == related_id), None)
            if related and st.button(related["title"], key=f'related_{related_id}'):
                navigate("업무 지식", related_id, "")
    if not framed:
        st.divider()
    with st.container(border=True, key="reading_sources") if framed else nullcontext():
        show_sources(article, sources)


def show_sources(article, sources):
    st.subheader("참고 자료")
    if not article["sources"]:
        st.caption("학습 제안 글입니다. 관련 출처는 검토 후 추가합니다.")
    for reference in article["sources"]:
        source = sources[reference["source"]]
        with st.expander(f'{source["title"]} · {reference["location"]}'):
            st.write(reference["note"])
            st.caption(f'자료 구분: {source["kind"]}')


try:
    content = load_content()
except (OSError, ValueError, KeyError) as error:
    st.error(f"콘텐츠를 불러오지 못했습니다. content 폴더를 확인해 주세요. ({error})")
    st.stop()

articles = content["articles"]
sources = content["sources"]
for name, value in st.session_state.pop("_navigation", {}).items():
    st.session_state[name] = value
st.session_state.setdefault("page", "홈")
st.session_state.setdefault("article", articles[0]["id"])
st.session_state.setdefault("query", "")

if st.query_params.get("nav") == "home":
    st.session_state["page"] = "홈"
    del st.query_params["nav"]

# Return sessions that were displaying the retired device page to the home page.
if st.session_state["page"] == "장비 안내":
    st.session_state["page"] = "홈"
# Preserve an already-open article when the knowledge menu is split.
if not st.session_state.get("_knowledge_groups_migrated"):
    if st.session_state["page"] == "업무 지식":
        selected = next((a for a in articles
                         if a["id"] == st.session_state.get("knowledge_article_choice")), None)
        if selected and article_page(selected) == "기초 지식":
            st.session_state["page"] = "기초 지식"
            st.session_state["basics_article_choice"] = selected["id"]
            st.session_state["basics_category"] = "전체"
            st.session_state["knowledge_article_choice"] = None
    st.session_state["_knowledge_groups_migrated"] = True
if st.session_state["page"] == "업무 지식":
    selected = next((a for a in articles
                     if a["id"] == st.session_state.get("knowledge_article_choice")), None)
    if selected and article_page(selected) == "기타 정보":
        st.session_state["page"] = "기타 정보"
        st.session_state["other_info_choice"] = selected["title"]
        st.session_state["knowledge_article_choice"] = None
page = st.session_state["page"]


def sidebar_link(label, icon):
    if st.button(
        label, icon=icon, key=f"nav_{label}", width="stretch",
        type="primary" if page == label else "secondary",
    ):
        navigate(label)


with st.sidebar:
    logo_data = base64.b64encode((ROOT / "assets/sansoft-logo.png").read_bytes()).decode("ascii")
    st.markdown(
        '<a class="sidebar-home-logo" href="?nav=home" target="_self" aria-label="홈으로 이동" title="홈으로 이동">'
        f'<img src="data:image/png;base64,{logo_data}" alt="산소프트" /></a>',
        unsafe_allow_html=True,
    )
    st.markdown('<p class="sidebar-identity">고객지원팀 · 업무 길잡이</p>', unsafe_allow_html=True)
    sidebar_link("홈", ":material/home:")
    st.markdown('<p class="nav-group">업무 가이드</p>', unsafe_allow_html=True)
    sidebar_link("업무 이해", ":material/menu_book:")
    sidebar_link("업무 지식", ":material/library_books:")
    sidebar_link("기초 지식", ":material/school:")
    sidebar_link("용어정리", ":material/format_color_text:")
    sidebar_link("기타 정보", ":material/folder_open:")
    st.markdown('<p class="nav-group">사례 관리</p>', unsafe_allow_html=True)
    sidebar_link("문의 사례", ":material/forum:")
    st.markdown('<p class="nav-group">자료 관리</p>', unsafe_allow_html=True)
    sidebar_link("업데이트 내역", ":material/history:")

creation_log = creation_records(entries(articles, get_cases()))

if page == "업데이트 내역":
    history_page(creation_log, open_home_entry)

elif page == "홈":
    st.title("고객지원 업무 길잡이")
    st.write("필요한 내용을 찾고, 자주 보는 자료는 가까이 두세요.")
    st.space("small")
    all_entries = entries(articles, get_cases())
    by_key = {item["key"]: item for item in all_entries}
    article_lookup = {a["id"]: a for a in articles}
    suggestions = []
    for item in all_entries:
        article = article_lookup.get(item["id"], {}) if item["kind"] == "article" else {}
        suggestions.append({"key": item["key"], "title": item["title"], "category": item["category"],
                            "search": " ".join([item["title"], item["category"], article.get("summary", ""),
                                                " ".join(article.get("tags", []))])})
    live_search = st.components.v2.component(
        "manual_home_search",
        js=(ROOT / "assets/home-search.js").read_text(encoding="utf-8"),
        css=(ROOT / "assets/home-search.css").read_text(encoding="utf-8"),
    )
    search_result = live_search(data=suggestions, key="home_live_search",
                                on_selected_change=lambda: None, on_query_change=lambda: None)
    if search_result.selected in by_key:
        open_home_entry(by_key[search_result.selected])
    if search_result.query:
        navigate("검색 결과", query=search_result.query)
    st.space("medium")
    recent, saved_column = st.columns([1.2, 1], gap="large")
    with recent:
        st.subheader("최근 추가·수정한 글")
        with st.container(key="home_recent"):
            for item in sorted(all_entries, key=lambda x: x["updated"], reverse=True)[:3]:
                home_row(item, "recent")
    with saved_column:
        st.subheader("즐겨찾기")
        saved_keys = [key for key in favorites() if key in by_key]
        st.caption(f"자주 찾는 자료 {len(saved_keys)}개 · 즐겨찾기는 현재 접속 중에 유지됩니다.")
        with st.container(key="home_favorites"):
            if not saved_keys:
                st.markdown("**자주 보는 자료를 담아보세요.**")
                st.caption("글의 즐겨찾기 버튼이나 아래 목록에서 추가할 수 있습니다.")
            for key in saved_keys:
                home_row(by_key[key], "saved")
        with st.expander("즐겨찾기 추가"):
            available = [item["key"] for item in all_entries if item["key"] not in saved_keys]
            chosen = st.selectbox("자료 검색", available, index=None, key="favorite_picker",
                format_func=lambda key: by_key[key]["title"] + " — " + by_key[key]["category"],
                placeholder="제목으로 검색해 선택하세요", disabled=not available)
            if st.button("즐겨찾기에 추가", disabled=chosen is None, key="favorite_add"):
                set_favorite(chosen, True)
                st.session_state["_navigation"] = {"favorite_picker": None}
                st.rerun()
    st.space("medium")
    with st.container(key="home_welcome"):
        intro, action = st.columns([3, 1], vertical_alignment="center")
        with intro:
            st.markdown("**처음 오셨나요?**")
            st.caption("회사와 제품, 데이터 흐름부터 순서대로 알아보세요.")
        with action:
            if st.button("업무 이해 시작하기 →", width="stretch"):
                navigate("업무 이해", articles[0]["id"])

elif page == "업무 이해":
    st.title("업무 이해")
    st.write("회사와 업무의 큰 흐름을 순서대로 읽어보세요.")
    ordered = sorted([a for a in articles if a.get("order")], key=lambda a: a["order"])
    ids = [a["id"] for a in ordered]
    chosen = st.session_state["article"]
    selected = chosen if chosen in ids else ids[0]
    position = ids.index(selected)
    st.space("small")
    left, right = st.columns([1.15, 3], gap="large")
    with left:
        with st.container(border=True, key="reading_outline"):
            st.subheader("읽을 순서")
            st.caption(f"전체 {len(ordered)}개 글 · 현재 {position + 1}번째")
            for item in ordered:
                if st.button(
                    f'{item["order"]:02d}　{item["section"]}',
                    key=f'reading_{item["id"]}', width="stretch",
                    type="primary" if item["id"] == selected else "secondary",
                ):
                    navigate("업무 이해", item["id"])
    with right:
        article = next(a for a in ordered if a["id"] == selected)
        show_article(article, sources, framed=True)
        previous, following = st.columns(2)
        if previous.button("← 이전 글", disabled=position == 0):
            navigate("업무 이해", ids[position - 1])
        if following.button("다음 글 →", disabled=position == len(ids) - 1, type="primary"):
            navigate("업무 이해", ids[position + 1])

elif page in ("기타 정보", "Fork 사용법"):
    st.title("기타 정보")
    st.write("업무에 참고할 도구 사용법과 안내를 모았습니다.")
    info_articles = {a["title"]: a for a in articles_for_page(articles, "기타 정보")}
    info_page = st.selectbox(
        "안내 검색", ["Fork 사용법", "SANSOFT.Ini 설정 안내", "SANSOFT.MDB 수정 안내", *info_articles], index=None, key="other_info_choice",
        placeholder="검색어를 입력하고 안내를 선택하세요",
    )
    if info_page in info_articles:
        st.divider()
        show_article(info_articles[info_page], sources, framed=True)
    elif info_page == "Fork 사용법":
        st.subheader("Fork 사용법")
        favorite_button("info:fork", "fork_favorite")
        st.markdown("Fork 사용 매뉴얼은 [산소프트 인트라넷](https://sites.google.com/view/sansoft04/%EC%9E%A5%EB%B9%84%EC%84%A4%EC%A0%95/%EA%B8%B0%ED%83%80-%EC%A0%95%EB%B3%B4/fork%EC%82%AC%EC%9A%A9%EB%B2%95)에서 확인할 수 있습니다.")
        with st.container(border=True, key="reading_header"):
            st.subheader("매뉴얼 찾아가기")
            st.markdown("**산소프트 인트라넷 → 우측 상단 장비설정 → 기타정보 → Fork 사용법**")
        with st.expander("인트라넷 매뉴얼 화면 보기", expanded=True):
            st.image(str(ROOT / "assets/manuals/fork/intranet-guide.png"),
                     caption="산소프트 인트라넷 · fork사용법 — 사용자 제공 화면", width="stretch")
        if st.button("관련 업무 · 인터페이스 백업본 관리 →", key="fork_backup_link"):
            navigate("업무 지식", "interface-backup", "")


    elif info_page == "SANSOFT.Ini 설정 안내":
        st.subheader("SANSOFT.Ini 설정 안내")
        favorite_button("info:ini", "ini_favorite")
        st.image(str(ROOT / "assets/manuals/ini/sansoft-ini-file.png"), caption="SANSOFT.Ini 파일", width="content")
        body = (ROOT / "content/sansoft-ini.md").read_text(encoding="utf-8")
        sections = body.split("\n## ")
        st.markdown(sections[0])
        for section in sections[1:]:
            heading, _, description = section.partition("\n")
            with st.expander(heading, expanded=heading == "MDB·Ini 파일 위치 찾기"):
                if heading == "MDB·Ini 파일 위치 찾기":
                    st.image(str(ROOT / "assets/manuals/file-location/device-folder.png"),
                             caption="내 PC에서 찾은 파일 위치 · SANSOFT.Ini와 SANSOFT.MDB", width="stretch")
                st.markdown(description)
        st.caption("출처: 산소프트 인트라넷 ‘SANSOFT.Ini 설명’ — 사용자 제공 원문을 바탕으로 정리")
        if st.button("관련 업무 · 인터페이스 백업본 관리 →", key="ini_backup_link"):
            navigate("업무 지식", "interface-backup", "")



    elif info_page == "SANSOFT.MDB 수정 안내":
        st.subheader("SANSOFT.MDB 수정 안내")
        favorite_button("info:mdb", "mdb_favorite")
        body = (ROOT / "content/sansoft-mdb.md").read_text(encoding="utf-8")
        sections = body.split("\n## ")
        st.markdown(sections[0])
        for section in sections[1:]:
            heading, _, description = section.partition("\n")
            with st.expander(heading, expanded=heading in ("MDB·Ini 파일 위치 찾기", "수정할 항목과 비교 기준")):
                if heading == "MDB·Ini 파일 위치 찾기":
                    st.image(str(ROOT / "assets/manuals/file-location/device-folder.png"),
                             caption="내 PC에서 찾은 파일 위치 · SANSOFT.Ini와 SANSOFT.MDB", width="stretch")
                st.markdown(description)
                if heading == "수정할 항목과 비교 기준":
                    st.image(str(ROOT / "assets/manuals/mdb/code-info.png"),
                             caption="Access의 TB_CodeInfo 화면 · 사용자 제공 참고 이미지", width=1000)
        if st.button("관련 업무 · 인터페이스 백업본 관리 →", key="mdb_backup_link"):
            navigate("업무 지식", "interface-backup", "")


elif page == "문의 사례":
    cases_page()
    case_id = st.session_state.get("displayed_case")
    case = next((c for c in get_cases() if c["id"] == case_id), None)
    if case:
        favorite_button("case:" + case["id"], "case_favorite")
        learning = [a for a in articles if case_id in a.get("cases", [])
                    and a["category"] == "임상병리학 기초" and a["id"] != "clinical-basics"]
        if learning:
            st.subheader("이 사례와 연결되는 기초 개념")
            for article in learning:
                if st.button(article["title"], key="case_learning_" + article["id"]):
                    navigate("업무 지식", article["id"], "")
    if case and case.get("show_links", False):
        for aid in case.get("related", []):
            a = next((a for a in articles if a["id"] == aid), None)
            if a and st.button("관련 글 · " + a["title"], key="case_link_" + aid):
                navigate("업무 지식", aid, "")
        if "source" in case.get("visible_fields", []) and case.get("source_id") in sources:
            show_sources({"id":case_id,"sources":[{"source":case["source_id"],"location":"사례 B","note":"전화 문의 후 작성한 개인 사례 기록"}]}, sources)
        if st.button("관련 용어 찾기 →", key="case_glossary"):
            navigate("용어정리")

elif page == "용어정리":
    st.title("용어정리")
    terms = json.loads((ROOT / "content/glossary.json").read_text(encoding="utf-8"))
    st.caption("업무에서 쓰이는 상황과 확인할 내용을 중심으로 정리했습니다. DB 학습 용어는 별도 분류에서 볼 수 있습니다.")
    group = st.selectbox("분류", ["전체"] + list(dict.fromkeys(t["category"] for t in terms)), key="term_category")
    matches = filter_terms(terms, "", group)
    ids = [t["id"] for t in matches]
    if st.session_state.get("term_choice") not in ids:
        st.session_state["term_choice"] = None
    labels = {}
    for t in matches:
        labels[t["id"]] = t["title"] + " — " + " · ".join([t["meaning"], *t.get("aliases", [])])
    tid = st.selectbox("용어 검색", ids, index=None, key="term_choice",
        format_func=lambda x: labels[x],
        placeholder="한글·영문·약어를 입력하고 용어를 선택하세요", disabled=not ids)
    st.caption("용어명·한글 뜻·별칭으로 후보를 찾습니다. 영문 ABC순, 한글 이름은 가나다순으로 이어집니다.")
    if not matches:
        st.info("해당 분류에 용어가 없습니다.")
    elif tid is None:
        st.caption(f"찾아볼 용어 {len(matches)}개 · 아직 선택한 용어가 없습니다.")
    else:
        t = next(t for t in matches if t["id"] == tid)
        st.divider()
        with st.container(border=True, key="glossary_detail"):
            st.caption(t["category"] + (" · 업무구분 " + t["classification"] if t.get("classification") else ""))
            st.subheader(t["title"])
            favorite_button("term:" + t["id"], "term_favorite")
            st.write("**" + t["meaning"] + "**")
            st.write(t["definition"])
            with st.container(key="doc_section_glossary_situation"):
                st.markdown("**이럴 때 쓰입니다**")
                st.write(t["situation"])
            with st.container(key="doc_section_glossary_usage"):
                st.markdown("**업무에서 확인할 것**")
                st.write(t["usage"])
            if t.get("practice"):
                with st.container(key="doc_section_glossary_practice"):
                    st.markdown("**실무에서 알아둘 점**")
                    st.markdown(t["practice"])
            if t.get("comparison"):
                with st.expander("COR · PARA 비교 — 일반 개념 초안", expanded=True):
                    st.markdown(t["comparison"])
            if t.get("unconfirmed"):
                st.info("**사내 정의 · 확인 필요**\n\n" + t["unconfirmed"])
        for aid in t["related"]:
            a = next(a for a in articles if a["id"] == aid)
            if st.button("관련 글 · " + a["title"], key="term_article_" + aid):
                navigate("업무 지식", aid, "")
        case_titles = {case["id"]: case["title"] for case in get_cases()} if t["cases"] else {}
        for cid in t["cases"]:
            if cid in case_titles and st.button("관련 사례 · " + case_titles[cid], key="term_case_" + cid):
                open_case(cid)
        if t.get("source_note"):
            st.caption("출처: " + t["source_note"])
        else:
            show_sources(t, sources)

elif page in ("업무 지식", "기초 지식", "검색 결과"):
    st.title(page)
    descriptions = {
        "업무 지식": "설치·설정·백업·장애 대응 등 실제 업무에 필요한 절차와 확인 방법을 찾아보세요.",
        "기초 지식": "검사·정도관리·데이터 흐름을 이해하는 데 필요한 배경 개념을 익혀보세요.",
        "검색 결과": "여러 메뉴의 문서를 함께 검색합니다.",
    }
    st.write(descriptions[page])
    prefix = {"업무 지식": "knowledge", "기초 지식": "basics", "검색 결과": "search"}[page]
    choice_key = prefix + "_article_choice"
    category_key = prefix + "_category"
    knowledge_articles = articles_for_page(articles, page)
    if page == "업무 지식":
        classification_key = prefix + "_classification"
        classifications = ["전체", "QC", "IF", "QC+IF"]
        if st.session_state.get(classification_key) not in classifications:
            st.session_state[classification_key] = "전체"
        classification = st.selectbox("업무구분", classifications, key=classification_key)
        st.caption("QC는 정도관리, IF는 장비·병원 전산 연동, QC+IF는 두 업무의 공통 자료입니다. 공통 자료는 QC+IF에서 확인하세요.")
        knowledge_articles = [a for a in knowledge_articles
                              if classification == "전체" or a.get("classification") == classification]
    categories = ["전체"] + list(dict.fromkeys(a["category"] for a in knowledge_articles))
    if st.session_state.get(category_key) not in categories:
        st.session_state[category_key] = "전체"
    category = st.selectbox("주제", categories, key=category_key)
    query = st.session_state.get("query", "") if page == "검색 결과" else ""
    if page == "검색 결과" and query:
        st.caption(f"홈 검색 결과: {query}")
        if st.button("홈 검색 조건 지우기", key="clear_home_search"):
            navigate("검색 결과", query="")
    matches = filter_articles(knowledge_articles, query, category)
    ids = [a["id"] for a in matches]
    # 첫 글을 자동 선택하지 않는다. 직접 연결한 글만 사전 선택한다.
    if st.session_state.get(choice_key) not in ids:
        st.session_state[choice_key] = None
    labels = {}
    for a in matches:
        keywords = list(dict.fromkeys(([article_page(a)] if page == "검색 결과" else [])
                                     + ([a["classification"]] if a.get("classification") else [])
                                     + [a["category"], *a["tags"]]))
        labels[a["id"]] = a["title"] + " — " + " · ".join(keywords)
    selected = st.selectbox(
        "문서 검색" if page == "검색 결과" else page + " 검색", ids, index=None,
        key=choice_key, filter_mode="contains",
        format_func=lambda aid: labels[aid],
        placeholder="검색어를 입력하고 아래에서 원하는 글을 선택하세요",
        disabled=not ids,
    )
    st.caption("검색창을 눌러 입력하면 제목·주제·키워드가 일치하는 글이 아래에 표시됩니다. 선택하면 본문이 열립니다.")
    if not matches:
        st.info("일치하는 글이 없습니다. 검색 조건이나 주제를 바꿔보세요.")
    elif selected is None:
        st.caption(f"찾아볼 글 {len(matches)}개 · 아직 선택한 글이 없습니다.")
    else:
        chosen_article = next(a for a in matches if a["id"] == selected)
        if page == "검색 결과":
            navigate(article_page(chosen_article), selected, "")
        else:
            st.divider()
            show_article(chosen_article, sources, framed=True)
