"""공유용 자료 목록과 접속 세션별 즐겨찾기."""
import json
import streamlit as st
from pathlib import Path
from datetime import datetime, timezone, timedelta

ROOT = Path(__file__).resolve().parent


def favorites():
    return list(st.session_state.get("_viewer_favorites", []))


def set_favorite(key, enabled):
    saved = favorites()
    if enabled and key not in saved:
        saved.insert(0, key)
    elif not enabled and key in saved:
        saved.remove(key)
    st.session_state["_viewer_favorites"] = saved


def article_page(article):
    """Keep menu placement consistent for search, favorites and related links."""
    if article.get("menu_page") == "기타 정보":
        return "기타 정보"
    if article.get("order"):
        return "업무 이해"
    return "기초 지식" if article.get("knowledge_group") == "background" else "업무 지식"


def articles_for_page(articles, page):
    return list(articles) if page == "검색 결과" else [a for a in articles if article_page(a) == page]


def filter_articles(articles, query="", category="전체"):
    normalize = lambda value: "".join(value.casefold().split())
    return [a for a in articles
            if (category == "전체" or a["category"] == category)
            and normalize(query) in normalize(" ".join([
                a["title"], a["summary"], a.get("body", ""),
                a.get("search_supplements", ""), *a["tags"]]))]


def entries(articles, cases):
    items = []
    for a in articles:
        modified = datetime.fromtimestamp((ROOT / "content" / a["file"]).stat().st_mtime,
                                         timezone(timedelta(hours=9))).isoformat()
        items.append(dict(key="article:" + a["id"], title=a["title"], category=article_page(a),
                          updated=a["updated"], id=a["id"], kind="article"))
    for c in cases:
        items.append(dict(key="case:" + c["id"], title=c["title"], category="문의 사례 · " + c.get("classification", ""),
                          updated=c["updated"], id=c["id"], kind="case"))
    for t in json.loads((ROOT / "content/glossary.json").read_text(encoding="utf-8")):
        items.append(dict(key="term:" + t["id"], title=t["title"], category="용어정리",
                          updated=t.get("updated", ""), id=t["id"], kind="term"))
    for key, title in [("fork", "Fork 사용법"), ("ini", "SANSOFT.Ini 설정 안내"), ("mdb", "SANSOFT.MDB 수정 안내")]:
        items.append(dict(key="info:" + key, title=title, category="기타 정보", updated="2026-10-23",
                          id=title, kind="info"))
    return items
