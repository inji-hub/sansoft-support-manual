## 먼저 이해하기
혈액학 결과는 항목명과 단위를 함께 봅니다. 같은 세포의 비율과 절대수도 별도 항목입니다.

XN 계열 장비 결과에서 자주 접한 항목입니다.

| 약어 | 영문·의미 |
| --- | --- |
| WBC | White Blood Cell Count, 백혈구 수 |
| RBC | Red Blood Cell Count, 적혈구 수 |
| HGB / Hb | Hemoglobin, 혈색소 |
| HCT | Hematocrit, 혈액에서 적혈구가 차지하는 용적 비율 |
| PLT | Platelet Count, 혈소판 수 |
| MCV | Mean Corpuscular Volume, 평균 적혈구 용적 |
| MCH | Mean Corpuscular Hemoglobin, 평균 적혈구 혈색소량 |
| MCHC | Mean Corpuscular Hemoglobin Concentration, 평균 적혈구 혈색소 농도 |
| RDW | Red Cell Distribution Width, 적혈구 크기의 변이 정도 |
| MPV | Mean Platelet Volume, 평균 혈소판 용적 |



백혈구 감별에서는 NEUT(호중구), LYMPH(림프구), MONO(단구), EO(호산구), BASO(호염기구) 등을 봅니다. 장비는 같은 세포 종류에 대해 **비율 %와 절대수 #를** 별도 항목으로 제공할 수 있습니다. [미시간대학교 CBC 안내](https://mlabs.umich.edu/tests/complete-blood-count-cbc), [Sysmex 항목 목록](https://www.sysmex.com/en-us//customer-support/tools/product-comparison/details)
## 업무에서 왜 필요한가
- **NEUT%와 NEUT#를** 같은 코드로 연결하지 않습니다.
- **RDW-SD와 RDW-CV**도 구분합니다.
- 특정 장비의 검사코드를 다른 장비의 공통 코드처럼 사용하지 않습니다.
- 단위와 항목명을 함께 대조합니다.

## 병원에 무엇을 확인할까
장비명·검사 코드·항목명·단위가 무엇인가요? NEUT%와 NEUT#, RDW-SD와 RDW-CV를 각각 대조합니다.
