## 먼저 이해하기
간염검사는 바이러스 종류, 항원·항체, Total·IgM을 나누어 정확한 항목명을 확인합니다.

## A형간염

| 항목 | 기본 의미 | 전화에서 말하기 |
| --- | --- | --- |
| Anti-HAV Total | A형간염 바이러스에 대한 총항체 검사. IgM·IgG를 포함 | A형간염 항체 토탈 |
| Anti-HAV IgM | 최근·급성 감염 평가 등에 사용하는 IgM 항체 검사 | A형간염 아이지엠 항체 |



**Total 양성만으로 급성 감염을 판단할 수는 없습니다.** Total과 IgM 결과, 증상·병력 등을 함께 해석합니다. [CDC A형간염 검사 안내](https://www.cdc.gov/hepatitis-a/hcp/diagnosis-testing/)
## B형간염

| 항목 | 구분 |
| --- | --- |
| HBV | B형간염 바이러스 자체를 뜻함 |
| HBsAg | B형간염 표면항원 |
| Anti-HBs / HBsAb | 표면항체 |
| Anti-HBc Total | 코어 항원에 대한 총항체 |
| Anti-HBc IgM | 코어 항원에 대한 IgM 항체 |
| HBeAg | e항원 |
| Anti-HBe / HBeAb | e항체 |



**HBc, HBs, HBe는 서로 다른 항목입니다.** 특히 anti-HBc를 그냥 HBV라고 기록하면 어떤 검사인지 특정하기 어렵습니다. B형간염 백신으로 생긴 면역에서는 일반적으로 anti-HBs가 형성되며, 백신만으로 anti-HBc가 형성되지는 않습니다. [CDC B형간염 검사 안내](https://www.cdc.gov/hepatitis-b/hcp/diagnosis-testing/), [CDC 검사 약어 정의](https://www.cdc.gov/pinkbook/hcp/table-of-contents/chapter-10-hepatitis-b.html)

> 항원·항체 결과 하나만으로 감염 상태나 전염력을 단정하지 않습니다.


## 업무에서 왜 필요한가
비슷한 발음의 검사명을 잘못 연결하면 다른 항목의 설정을 확인하게 됩니다. 판정 기준은 실제 검사 제품과 장비에 따라 확인합니다.

## 병원에 무엇을 확인할까
영문 검사명과 장비 코드는 무엇인가요? 항원인지 항체인지, Total인지 IgM인지 확인하고 불명확한 발음은 확정하지 않습니다.
