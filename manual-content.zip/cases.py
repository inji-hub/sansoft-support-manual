"""문의 사례 저장과 화면. 원본 기록과 해결 확인 상태를 구분한다."""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parent
STATUSES = ["완료", "일부 완료", "확인 대기", "설치 진행 중", "확인 중", "조치 후 결과 미확인", "응대 종료", "해결 확인"]
FIELDS = {
    "received": "접수일", "classification": "업무구분",
    "title": "제목", "environment": "환경 (프로그램·장비·버전·연결 방식)",
    "symptom": "증상", "observations": "확인한 사실",
    "cause": "원인 또는 가설 (확정 여부 포함)", "action": "안내·수행한 조치",
    "result": "결과와 확인 방법", "lesson": "배운 점·추가 확인 사항",
    "source": "출처·관련 자료",
}


def get_cases():
    records = json.loads((ROOT / "content/cases.json").read_text(encoding="utf-8"))
    return sorted(records, key=lambda case: (case["featured"], case["updated"]), reverse=True)





def open_case(case_id):
    st.session_state["selected_case"] = case_id
    st.session_state["_navigation"] = {"page": "문의 사례", "case_mode": "사례 찾아보기", "case_choice": case_id}
    st.session_state.pop("case_query", None)
    st.session_state.pop("case_status", None)
    st.session_state.pop("case_classification", None)
    st.rerun()


def featured_cases():
    st.subheader("대표 문의 사례")
    cases = [c for c in get_cases() if c["featured"]]
    if not cases:
        st.caption("문의 사례에서 자주 참고할 항목을 대표 사례로 지정해 보세요.")
    for case in cases:
        with st.container(border=True):
            st.caption(case["status"])
            if st.button(case["title"], key=f'featured_{case["id"]}', width="stretch"):
                open_case(case["id"])
            st.write(case["symptom"])
    if st.button("문의 사례 전체 보기 →"):
        open_case(None)


OPTIONAL_FIELDS = [k for k in FIELDS if k not in ("title", "symptom", "classification")]
DEFAULT_FIELDS = ["classification", "observations", "cause", "action"]
CLASSIFICATIONS = ["IF", "QC", "QC+IF"]


def visible_fields(case):
    selected = case.get("visible_fields", DEFAULT_FIELDS)
    return [k for k in FIELDS if k != "title" and
            (k == "symptom" or k in selected) and str(case.get(k, "")).strip()]






def inline_log_image(case):
    anchor = "설정상 문제는 발견되지 않아 **문제 로그와 정상 로그를 비교**했습니다."
    if (case["id"] == "qc-log-header-missing-20261026"
            and case.get("show_attachments", True)
            and anchor in case.get("observations", "")):
        for item in case.get("attachments", []):
            path = (ROOT / item.get("path", "")).resolve()
            if path.is_relative_to(ROOT.resolve()) and path.is_file():
                return anchor, item, path
    return None


def inline_step_images(case, field):
    """지정 문장 뒤에 표시할 단계별 첨부를 본문 순서대로 반환한다."""
    if not case.get("show_attachments", True):
        return []
    text = case.get(field, "")
    found = []
    for item in case.get("attachments", []):
        anchor = item.get("inline_after", "")
        if item.get("inline_field") != field or not anchor or anchor not in text:
            continue
        path = (ROOT / item.get("path", "")).resolve()
        if path.is_relative_to(ROOT.resolve()) and path.is_file():
            found.append((anchor, item, path))
    return sorted(found, key=lambda entry: text.index(entry[0]))


def render_case_details(case):
    """공통 사례 표시. 내용과 표시 항목은 저장된 사례에서 읽는다."""
    st.markdown("""
    <style>
    .st-key-case_detail_symptom {
        background:#f1f7fa;border-left:4px solid #378b90;border-radius:10px;padding:1.2rem 1.4rem;
    }
    .st-key-case_detail_observations {
        background:#fff;border:1px solid #dce8e9;border-radius:12px;padding:1.4rem;
    }
    .st-key-case_detail_observations ol {
        display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem;
        padding:0;list-style-position:inside;
    }
    .st-key-case_detail_observations ol li {
        background:#f3f7f9;border:1px solid #e3ebef;border-radius:8px;
        padding:1rem;margin:0!important;overflow-wrap:anywhere;
    }
    .st-key-case_detail_observations ol li::marker {color:#28747a;font-weight:700}

    .st-key-case_detail_observations ol > li > h3 {
        font-size:1.25rem!important;line-height:1.5!important;
        margin:0 0 .85rem!important;padding:0!important;color:#183b4b;
    }
    .st-key-case_detail_observations ol > li:has(> ul) {grid-column:1 / -1}
    .st-key-case_detail_observations ol > li > ul {
        display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem;
        padding:0;margin:.8rem 0;list-style:none;
    }
    .st-key-case_detail_observations ol > li > ul > li {
        background:#fff;padding:1rem;border:1px solid #dce8e9;
    }
    @media(max-width:700px) {
        .st-key-case_detail_observations ol > li > ul {grid-template-columns:1fr}
    }

    .st-key-case_detail_observations blockquote {
        background:#e8f5ef;border-left:4px solid #378467;border-radius:6px;
        padding:.9rem 1rem;margin:1.2rem 0 0;color:#205b46;
    }
    .st-key-case_detail_observations blockquote p {margin-bottom:0!important}
    .st-key-case_detail_action ol {padding-left:1.5rem}
    .st-key-case_detail_action li {
        border-bottom:1px solid #e3e9ed;padding:.25rem .25rem 1rem .5rem;margin-bottom:1rem!important;
    }
    .st-key-case_detail_action li::marker {font-weight:700;color:#28747a}
    .st-key-case_detail_action li:last-child {border-bottom:0}
    @media(max-width:700px) {
        .st-key-case_detail_observations ol {grid-template-columns:1fr}
        .st-key-case_detail_observations,.st-key-case_detail_symptom {padding:1rem}
    }
    </style>
    """, unsafe_allow_html=True)
    if case["id"] != "pathfast-name-20261022":
        st.markdown("<style>.st-key-case_detail_observations blockquote {background:#f0f6f8;border-color:#378b90;color:#254452}</style>", unsafe_allow_html=True)
    labels = {"environment":"대상 환경", "symptom":"문의 내용",
              "observations":"확인 과정", "action":"조치 내용"}
    for key in visible_fields(case):
        if key == "classification":
            continue
        st.subheader(labels.get(key, FIELDS[key]))
        with st.container(key="case_detail_" + key):
            text = case[key]
            detail_heading = "### 데이터 전송 상세 절차"
            following_heading = "**Control 등록 시 비교할 항목**"
            inline = inline_log_image(case) if key == "observations" else None
            step_images = inline_step_images(case, key)
            if step_images:
                remaining = text
                for anchor, item, image_path in step_images:
                    before, remaining = remaining.split(anchor, 1)
                    st.markdown(before + anchor)
                    st.image(str(image_path), caption=item.get("caption", ""), width="content")
                if remaining.strip():
                    st.markdown(remaining)
            elif inline:
                anchor, item, image_path = inline
                before, after = text.split(anchor, 1)
                st.markdown(before + anchor)
                st.image(str(image_path), caption="왼쪽: 헤더가 누락된 문제 로그 / 오른쪽: 헤더가 있는 정상 로그", width="content")
                st.markdown(after)
            elif (case["id"] == "cor-para-settings-20261023"
                    and key == "observations"
                    and detail_heading in text):
                overview, detail = text.split(detail_heading, 1)
                detail, separator, following = detail.partition(following_heading)
                st.markdown(overview.rstrip().removesuffix("---").rstrip())
                with st.expander("데이터 전송 상세 절차", expanded=False):
                    st.markdown(detail.strip())
                if separator:
                    st.markdown(separator + following)
            else:
                st.markdown(text)


def cases_page():
    st.title("문의 사례")
    st.write("업무구분과 진행 상태로 문의 사례를 찾아보세요.")
    st.session_state.pop("displayed_case", None)
    records = get_cases()
    status_column, classification_column = st.columns(2)
    status = status_column.selectbox("진행 상태 필터", ["전체"] + STATUSES, key="case_status")
    classification = classification_column.selectbox("업무구분 필터", ["전체"] + CLASSIFICATIONS, key="case_classification")
    matches = [c for c in records if (status == "전체" or c["status"] == status)
               and (classification == "전체" or c.get("classification") == classification)]
    st.caption(f"{len(matches)}건 · 대표 사례가 먼저 표시됩니다.")
    if not matches:
        st.info("일치하는 사례가 없습니다. 검색 조건을 바꿔 보세요.")
        return
    ids = [c["id"] for c in matches]
    if st.session_state.get("case_choice") not in ids:
        st.session_state["case_choice"] = None
    labels = {c["id"]: ("★ " if c["featured"] else "") + c["title"]
              + " — " + c.get("classification", "") for c in matches}
    selected = st.selectbox("사례 검색", ids, index=None, key="case_choice",
        format_func=lambda cid: labels[cid],
        placeholder="제목이나 업무구분을 입력하고 사례를 선택하세요")
    st.caption("검색창 아래 후보 목록에서 원하는 사례를 선택하면 내용이 열립니다.")
    if selected is None:
        st.caption("아직 선택한 사례가 없습니다.")
        return
    st.divider()
    case = next(c for c in matches if c["id"] == selected)
    st.session_state["displayed_case"] = selected
    st.header(case["title"])
    classification = case.get("classification", "")
    badge_colors = {
        "IF": ("#e8efff", "#214c96", "#c7d8f8"),
        "QC": ("#e0f2ee", "#176354", "#b8ded4"),
        "QC+IF": ("#eee8fa", "#634098", "#d9caef"),
    }
    if classification in badge_colors:
        background, foreground, border = badge_colors[classification]
        st.markdown(
            f'<div style="display:flex;align-items:center;gap:12px;margin:4px 0 20px">'
            f'<span style="font-size:14px;color:#526675;font-weight:600">업무구분</span>'
            f'<span style="display:inline-block;padding:7px 18px;border-radius:8px;'
            f'background:{background};color:{foreground};border:1px solid {border};'
            f'font-size:18px;font-weight:700;letter-spacing:.04em">{classification}</span></div>',
            unsafe_allow_html=True,
        )
    if case.get("show_status", True):
        st.caption(case["status"])
    render_case_details(case)
    if case["id"] == "wbc-target-20261021":
        from visuals import diagram, manual_pages
        if case.get("show_diagram", True):
            with st.expander("접수 당시 확인 과정 그림", expanded=True):
                diagram("wbc-case", "2026-10-21 접수 당시 기록을 재구성한 그림입니다. 이후 수정한 진행 상태와는 구분됩니다.")
        if case.get("show_manual", False):
            manual_pages([8])
    inline = inline_log_image(case)
    placed = [entry[1] for field in visible_fields(case) for entry in inline_step_images(case, field)]
    attachments = [item for item in case.get("attachments", [])
                   if (not inline or item != inline[1]) and item not in placed]
    if attachments and case.get("show_attachments", True):
        st.subheader("조치 화면")
        tabs = st.tabs([item["title"] for item in attachments])
        for tab, item in zip(tabs, attachments):
            with tab:
                if item.get("guide"):
                    st.markdown(item["guide"])
                if item.get("pending") and not item.get("path"):
                    st.info("스크린샷 추가 예정")
                    if item.get("caption"):
                        st.caption(item["caption"])
                    continue
                image_path = (ROOT / item["path"]).resolve()
                if image_path.is_relative_to(ROOT.resolve()) and image_path.is_file():
                    st.image(str(image_path), caption=item.get("caption", ""), width="content")
                else:
                    st.warning("첨부 이미지를 찾을 수 없습니다.")
