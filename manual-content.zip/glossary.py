"""용어명 검색과 일관된 목록 정렬."""
import re


def normalize(value):
    return "".join(value.casefold().split())


def sort_key(term):
    title = term["title"]
    # 한글 이름 뒤에 영문 별칭이 있는 용어도 해당 영문 위치에 정렬한다.
    english_name = next((part.strip() for part in title.split("·")
                         if re.match(r"[A-Za-z]", part.strip())), "")
    english = re.search(r"[A-Za-z][A-Za-z0-9 /.-]*", english_name)
    if english:
        return (0, english.group().strip().casefold(), title)
    return (1, title, title)


def filter_terms(terms, query="", category="전체"):
    query = normalize(query)
    return sorted(
        (term for term in terms
         if (category == "전체" or term["category"] == category)
         and any(query in normalize(name) for name in
                 [term["title"], term["meaning"], *term.get("aliases", [])])),
        key=sort_key,
    )
